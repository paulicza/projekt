from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin
from flask_migrate import Migrate

app = Flask(__name__)
app.config.from_object('config.Config')

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'auth.login' 

from app.models import User, Restaurant, Reservation  

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

from app import routes
from app.blueprints.auth import auth_bp 
app.register_blueprint(auth_bp) 
from app.blueprints.reservation import reservation_bp
app.register_blueprint(reservation_bp, url_prefix='/reservation')
from app.blueprints.admin import admin_bp
app.register_blueprint(admin_bp)
from app.blueprints.owner import owner_bp
app.register_blueprint(owner_bp)


