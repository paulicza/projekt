from flask import render_template, url_for, flash, redirect, request, Blueprint
from app import db
from app.models import Reservation, Restaurant 
from app.decorators import role_required
from flask_login import login_required, current_user
from datetime import datetime

admin_bp = Blueprint('admin', __name__, template_folder='templates')

@admin_bp.route('/admin_panel')
@login_required
@role_required('admin')
def admin_panel():
    if current_user.role != 'admin':
        flash('Nie masz uprawnień do wejścia na tę stronę.', 'danger')
        return redirect(url_for('index'))
    
    reservations = Reservation.query.all()
    current_time = datetime.now()
    past_reservations = [reservation for reservation in reservations if reservation.date < current_time]
    future_reservations = [reservation for reservation in reservations if reservation.date >= current_time]
    return render_template('admin.html', reservations=reservations, past_reservations=past_reservations, future_reservations=future_reservations)

@admin_bp.route('/admin_delete_reservation/<int:reservation_id>', methods=['POST'])
@login_required
@role_required('admin')
def admin_delete_reservation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    db.session.delete(reservation)
    db.session.commit()
    flash('Rezerwacja usunięta pomyślnie', 'success')
    return redirect(url_for('admin.admin_panel'))