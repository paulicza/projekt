from flask import render_template, url_for, flash, redirect, request
from app import app, db
from app.decorators import role_required
from app.models import Restaurant, Reservation
from flask_login import login_required, current_user
from datetime import datetime

@app.route('/')
@app.route('/index')
def index():
    if current_user.is_authenticated and current_user.role == 'admin':
        return redirect(url_for('admin_panel'))
    if current_user.is_authenticated and current_user.role == 'owner':
        return redirect(url_for('owner_panel'))
    restaurants = Restaurant.query.all()
    return render_template('index.html', restaurants=restaurants)

@app.route('/reservations')
@login_required
@role_required('owner')
def view_reservations():
    reservations = Reservation.query.filter_by(user_id=current_user.id).all()
    return render_template('reservations.html', reservations=reservations)

@app.route('/admin_panel')
@login_required
@role_required('admin')
def admin_panel():
    if current_user.role != 'admin':
        flash('You are not authorized to access this page.', 'danger')
        return redirect(url_for('index'))
    reservations = Reservation.query.all()
    return render_template('admin.html', reservations=reservations)

@app.route('/owner_panel')
@login_required
@role_required('owner')
def owner_panel():
    if current_user.role != 'owner':
        flash('You are not authorized to access this page.', 'danger')
        return redirect(url_for('index'))
    reservations = Reservation.query.all()
    return render_template('owner.html', reservations=reservations)

