from app import app, db
from app.models import Restaurant, User
from werkzeug.security import generate_password_hash

with app.app_context():
    # OLA TUTAJ DODAJ W TEN SPOSÓB TE RESTAURACJE
    restaurant1 = Restaurant(name='Restaurant 1', location='Krakow', menu='Menu 1', capacity=100)
    restaurant2 = Restaurant(name='Restaurant 2', location='Krakow', menu='Menu 2', capacity=150)
    db.session.add(restaurant1)
    db.session.add(restaurant2)

    hashed_password = generate_password_hash('password123', method='pbkdf2')

    # dodanie właściciela i admina
    owner_password = generate_password_hash('owner1', method='pbkdf2')
    owner = User(username='owner1', email='owner1@example.com', password=owner_password, role='owner')
    db.session.add(owner)

    admin_password = generate_password_hash('admin1', method='pbkdf2')
    admin = User(username='admin1', email='admin1@example.com', password=admin_password, role='admin')
    db.session.add(admin)

    db.session.commit()
