from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin
from flask_migrate import Migrate

app = Flask(__name__)
app.config.from_object('config.Config')

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'auth.login'  # Specify the login view for Flask-Login

from app.models import User, Restaurant, Reservation  # Import User model

@login_manager.user_loader
def load_user(user_id):
    # Since the user_id is just the primary key of our user table, use it in the query for the user
    return User.query.get(int(user_id))

from app import routes
from app.blueprints.auth import auth_bp  # Import the blueprint object
app.register_blueprint(auth_bp)  # Register the blueprint with the main app
from app.blueprints.reservation import reservation_bp
app.register_blueprint(reservation_bp, url_prefix='/reservation')
from app.blueprints.admin import admin_bp
app.register_blueprint(admin_bp)
from app.blueprints.owner import owner_bp
app.register_blueprint(owner_bp)


