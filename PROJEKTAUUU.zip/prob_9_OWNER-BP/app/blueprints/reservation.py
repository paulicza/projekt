from flask import render_template, url_for, flash, redirect, request, Blueprint
from app import db
from app.models import Reservation, Restaurant  # Załóżmy, że Restaurant jest modelem Twojej restauracji
from flask_login import login_required, current_user
from datetime import datetime

reservation_bp = Blueprint('reservation', __name__, template_folder='templates')

@reservation_bp.route('/make_reservation/<int:restaurant_id>', methods=['GET', 'POST'])
@login_required
def make_reservation(restaurant_id):
    restaurant = Restaurant.query.get_or_404(restaurant_id)  # Pobieramy restaurację na podstawie ID

    if request.method == 'POST':
        guests = request.form.get('guests')
        menu_choice = request.form.get('menu_choice')
        reservation_date = request.form.get('reservation_date')

        # Możesz dodać swoją logikę walidacji tutaj

        if guests and menu_choice and reservation_date:
            # Tworzymy rezerwację
            reservation = Reservation(
                date=datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M'),  # Konwertujemy string na datetime
                guests=guests,
                menu_choice=menu_choice,
                user_id=current_user.id,
                restaurant_id=restaurant_id
            )
            db.session.add(reservation)
            db.session.commit()

            flash('Rezerwacja została dokonana pomyślnie!', 'success')

            # Przekierowanie na stronę potwierdzenia rezerwacji
            return redirect(url_for('reservation.reservation_confirmation'))

        flash('Wystąpił problem podczas przetwarzania rezerwacji. Proszę spróbować ponownie.', 'danger')
        return redirect(url_for('index'))

    # Przekazujemy restaurację do szablonu
    return render_template('make_reservation.html', restaurant=restaurant)

@reservation_bp.route('/reservation_confirmation')
def reservation_confirmation():
    return render_template('reservation_confirmation.html')

@reservation_bp.route('/my_reservations')
@login_required
def my_reservations():
    reservations = Reservation.query.filter_by(user_id=current_user.id).all()
    return render_template('my_reservations.html', reservations=reservations)
